$(document).ready(function(){ 
  var search_field_id = "#search_autocomplete";

  // ref: https://stackoverflow.com/a/2684561/950494
  jQuery.expr[':'].focus = function(elem) {
    return elem === document.activeElement && (elem.type || elem.href);
  };

  // F3 or CTRL+F or COMMAND+F -> focus on search box
  window.addEventListener("keydown",function (e) {
    //console.log(e.keyCode);
    if(e.keyCode === 114 || (e.ctrlKey && e.keyCode === 70) || (e.metaKey && e.keyCode === 70)){
      if($(search_field_id).is(":focus")) {
        return true;
      }
      else {
        e.preventDefault();
        $(search_field_id).focus();
      }
    }
  })
})